import './Header.css'

export function Header(){
    return (
        <header>
            <h1>Sou o cabeçalho</h1>
            <p>Parágrafo pra dar uma incrementada mais</p>
        </header>
    )
}